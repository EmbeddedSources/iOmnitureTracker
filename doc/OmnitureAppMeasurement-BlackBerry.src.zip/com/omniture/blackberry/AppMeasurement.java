/*      */ package com.omniture.blackberry;
/*      */ 
/*      */ import java.io.PrintStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.util.Calendar;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Random;
/*      */ import java.util.TimeZone;
/*      */ import java.util.Vector;
/*      */ import net.rim.device.api.i18n.Locale;
/*      */ import net.rim.device.api.system.ApplicationDescriptor;
/*      */ import net.rim.device.api.system.DeviceInfo;
/*      */ 
/*      */ public class AppMeasurement
/*      */ {
/*      */   private String version;
/*      */   private String[] requiredVarList;
/*      */   private String[] accountConfigList;
/*      */   private Vector accountVarList;
/*      */   private Hashtable accountVarConstants;
/*      */   private static Vector requestList;
/*   29 */   private static AppMeasurement singletonInstance = null;
/*      */   private String pe;
/*      */   private String pev1;
/*      */   private String pev2;
/*      */   public String account;
/*      */   public String linkURL;
/*      */   public String linkName;
/*      */   public String linkType;
/*      */   public String linkTrackVars;
/*      */   public String linkTrackEvents;
/*      */   public String dc;
/*      */   public String trackingServer;
/*      */   public String trackingServerSecure;
/*      */   public String userAgent;
/*      */   public String dynamicVariablePrefix;
/*      */   public String visitorID;
/*      */   public String charSet;
/*      */   public String visitorNamespace;
/*      */   public String pageName;
/*      */   public String pageURL;
/*      */   public String referrer;
/*      */   public String currencyCode;
/*      */   public String purchaseID;
/*      */   public String channel;
/*      */   public String server;
/*      */   public String pageType;
/*      */   public String transactionID;
/*      */   public String campaign;
/*      */   public String state;
/*      */   public String zip;
/*      */   public String events;
/*      */   public String products;
/*      */   public String hier1;
/*      */   public String hier2;
/*      */   public String hier3;
/*      */   public String hier4;
/*      */   public String hier5;
/*      */   public String prop1;
/*      */   public String prop2;
/*      */   public String prop3;
/*      */   public String prop4;
/*      */   public String prop5;
/*      */   public String prop6;
/*      */   public String prop7;
/*      */   public String prop8;
/*      */   public String prop9;
/*      */   public String prop10;
/*      */   public String prop11;
/*      */   public String prop12;
/*      */   public String prop13;
/*      */   public String prop14;
/*      */   public String prop15;
/*      */   public String prop16;
/*      */   public String prop17;
/*      */   public String prop18;
/*      */   public String prop19;
/*      */   public String prop20;
/*      */   public String prop21;
/*      */   public String prop22;
/*      */   public String prop23;
/*      */   public String prop24;
/*      */   public String prop25;
/*      */   public String prop26;
/*      */   public String prop27;
/*      */   public String prop28;
/*      */   public String prop29;
/*      */   public String prop30;
/*      */   public String prop31;
/*      */   public String prop32;
/*      */   public String prop33;
/*      */   public String prop34;
/*      */   public String prop35;
/*      */   public String prop36;
/*      */   public String prop37;
/*      */   public String prop38;
/*      */   public String prop39;
/*      */   public String prop40;
/*      */   public String prop41;
/*      */   public String prop42;
/*      */   public String prop43;
/*      */   public String prop44;
/*      */   public String prop45;
/*      */   public String prop46;
/*      */   public String prop47;
/*      */   public String prop48;
/*      */   public String prop49;
/*      */   public String prop50;
/*      */   public String eVar1;
/*      */   public String eVar2;
/*      */   public String eVar3;
/*      */   public String eVar4;
/*      */   public String eVar5;
/*      */   public String eVar6;
/*      */   public String eVar7;
/*      */   public String eVar8;
/*      */   public String eVar9;
/*      */   public String eVar10;
/*      */   public String eVar11;
/*      */   public String eVar12;
/*      */   public String eVar13;
/*      */   public String eVar14;
/*      */   public String eVar15;
/*      */   public String eVar16;
/*      */   public String eVar17;
/*      */   public String eVar18;
/*      */   public String eVar19;
/*      */   public String eVar20;
/*      */   public String eVar21;
/*      */   public String eVar22;
/*      */   public String eVar23;
/*      */   public String eVar24;
/*      */   public String eVar25;
/*      */   public String eVar26;
/*      */   public String eVar27;
/*      */   public String eVar28;
/*      */   public String eVar29;
/*      */   public String eVar30;
/*      */   public String eVar31;
/*      */   public String eVar32;
/*      */   public String eVar33;
/*      */   public String eVar34;
/*      */   public String eVar35;
/*      */   public String eVar36;
/*      */   public String eVar37;
/*      */   public String eVar38;
/*      */   public String eVar39;
/*      */   public String eVar40;
/*      */   public String eVar41;
/*      */   public String eVar42;
/*      */   public String eVar43;
/*      */   public String eVar44;
/*      */   public String eVar45;
/*      */   public String eVar46;
/*      */   public String eVar47;
/*      */   public String eVar48;
/*      */   public String eVar49;
/*      */   public String eVar50;
/*      */   public boolean ssl;
/*      */   public boolean linkLeaveQueryString;
/*      */   public boolean debugTracking;
/*      */   public boolean usePlugins;
/*      */   public AppMeasurementDelegate delegate;
/*  177 */   private final int ACCOUNT = 1;
/*  178 */   private final int LINK_URL = 2;
/*  179 */   private final int LINK_NAME = 3;
/*  180 */   private final int LINK_TYPE = 4;
/*  181 */   private final int LINK_TRACK_VARS = 5;
/*  182 */   private final int LINK_TRACK_EVENTS = 6;
/*  183 */   private final int DC = 7;
/*  184 */   private final int TRACKING_SERVER = 8;
/*  185 */   private final int TRACKING_SERVER_SECURE = 9;
/*  186 */   private final int USER_AGENT = 10;
/*  187 */   private final int DYNAMIC_VARIABLE_PREFIX = 11;
/*  188 */   private final int VISITOR_ID = 12;
/*  189 */   private final int CHAR_SET = 13;
/*  190 */   private final int VISITOR_NAMESPACE = 14;
/*  191 */   private final int PAGE_NAME = 15;
/*  192 */   private final int PAGE_URL = 16;
/*  193 */   private final int REFERRER = 17;
/*  194 */   private final int CURRENCY_CODE = 18;
/*  195 */   private final int PURCHASE_ID = 19;
/*  196 */   private final int CHANNEL = 20;
/*  197 */   private final int SERVER = 21;
/*  198 */   private final int PAGE_TYPE = 22;
/*  199 */   private final int TRANSACTION_ID = 23;
/*  200 */   private final int CAMPAIGN = 24;
/*  201 */   private final int STATE = 25;
/*  202 */   private final int ZIP = 26;
/*  203 */   private final int EVENTS = 27;
/*  204 */   private final int PRODUCTS = 28;
/*  205 */   private final int HIER1 = 29;
/*  206 */   private final int HIER2 = 30;
/*  207 */   private final int HIER3 = 31;
/*  208 */   private final int HIER4 = 32;
/*  209 */   private final int HIER5 = 33;
/*  210 */   private final int PROP1 = 34;
/*  211 */   private final int PROP2 = 35;
/*  212 */   private final int PROP3 = 36;
/*  213 */   private final int PROP4 = 37;
/*  214 */   private final int PROP5 = 38;
/*  215 */   private final int PROP6 = 39;
/*  216 */   private final int PROP7 = 40;
/*  217 */   private final int PROP8 = 41;
/*  218 */   private final int PROP9 = 42;
/*  219 */   private final int PROP10 = 43;
/*  220 */   private final int PROP11 = 44;
/*  221 */   private final int PROP12 = 45;
/*  222 */   private final int PROP13 = 46;
/*  223 */   private final int PROP14 = 47;
/*  224 */   private final int PROP15 = 48;
/*  225 */   private final int PROP16 = 49;
/*  226 */   private final int PROP17 = 50;
/*  227 */   private final int PROP18 = 51;
/*  228 */   private final int PROP19 = 52;
/*  229 */   private final int PROP20 = 53;
/*  230 */   private final int PROP21 = 54;
/*  231 */   private final int PROP22 = 55;
/*  232 */   private final int PROP23 = 56;
/*  233 */   private final int PROP24 = 57;
/*  234 */   private final int PROP25 = 58;
/*  235 */   private final int PROP26 = 59;
/*  236 */   private final int PROP27 = 60;
/*  237 */   private final int PROP28 = 61;
/*  238 */   private final int PROP29 = 62;
/*  239 */   private final int PROP30 = 63;
/*  240 */   private final int PROP31 = 64;
/*  241 */   private final int PROP32 = 65;
/*  242 */   private final int PROP33 = 66;
/*  243 */   private final int PROP34 = 67;
/*  244 */   private final int PROP35 = 68;
/*  245 */   private final int PROP36 = 69;
/*  246 */   private final int PROP37 = 70;
/*  247 */   private final int PROP38 = 71;
/*  248 */   private final int PROP39 = 72;
/*  249 */   private final int PROP40 = 73;
/*  250 */   private final int PROP41 = 74;
/*  251 */   private final int PROP42 = 75;
/*  252 */   private final int PROP43 = 76;
/*  253 */   private final int PROP44 = 77;
/*  254 */   private final int PROP45 = 78;
/*  255 */   private final int PROP46 = 79;
/*  256 */   private final int PROP47 = 80;
/*  257 */   private final int PROP48 = 81;
/*  258 */   private final int PROP49 = 82;
/*  259 */   private final int PROP50 = 83;
/*  260 */   private final int EVAR1 = 84;
/*  261 */   private final int EVAR2 = 85;
/*  262 */   private final int EVAR3 = 86;
/*  263 */   private final int EVAR4 = 87;
/*  264 */   private final int EVAR5 = 88;
/*  265 */   private final int EVAR6 = 89;
/*  266 */   private final int EVAR7 = 90;
/*  267 */   private final int EVAR8 = 91;
/*  268 */   private final int EVAR9 = 92;
/*  269 */   private final int EVAR10 = 93;
/*  270 */   private final int EVAR11 = 94;
/*  271 */   private final int EVAR12 = 95;
/*  272 */   private final int EVAR13 = 96;
/*  273 */   private final int EVAR14 = 97;
/*  274 */   private final int EVAR15 = 98;
/*  275 */   private final int EVAR16 = 99;
/*  276 */   private final int EVAR17 = 100;
/*  277 */   private final int EVAR18 = 101;
/*  278 */   private final int EVAR19 = 102;
/*  279 */   private final int EVAR20 = 103;
/*  280 */   private final int EVAR21 = 104;
/*  281 */   private final int EVAR22 = 105;
/*  282 */   private final int EVAR23 = 106;
/*  283 */   private final int EVAR24 = 107;
/*  284 */   private final int EVAR25 = 108;
/*  285 */   private final int EVAR26 = 109;
/*  286 */   private final int EVAR27 = 110;
/*  287 */   private final int EVAR28 = 111;
/*  288 */   private final int EVAR29 = 112;
/*  289 */   private final int EVAR30 = 113;
/*  290 */   private final int EVAR31 = 114;
/*  291 */   private final int EVAR32 = 115;
/*  292 */   private final int EVAR33 = 116;
/*  293 */   private final int EVAR34 = 117;
/*  294 */   private final int EVAR35 = 118;
/*  295 */   private final int EVAR36 = 119;
/*  296 */   private final int EVAR37 = 120;
/*  297 */   private final int EVAR38 = 121;
/*  298 */   private final int EVAR39 = 122;
/*  299 */   private final int EVAR40 = 123;
/*  300 */   private final int EVAR41 = 124;
/*  301 */   private final int EVAR42 = 125;
/*  302 */   private final int EVAR43 = 126;
/*  303 */   private final int EVAR44 = 127;
/*  304 */   private final int EVAR45 = 128;
/*  305 */   private final int EVAR46 = 129;
/*  306 */   private final int EVAR47 = 130;
/*  307 */   private final int EVAR48 = 131;
/*  308 */   private final int EVAR49 = 132;
/*  309 */   private final int EVAR50 = 133;
/*  310 */   private final int PE = 134;
/*  311 */   private final int PEV1 = 135;
/*  312 */   private final int PEV2 = 136;
/*      */ 
/*      */   public static AppMeasurement getInstance()
/*      */   {
/*  324 */     if (singletonInstance == null) {
/*  325 */       singletonInstance = new AppMeasurement();
/*      */     }
/*      */ 
/*  328 */     return singletonInstance;
/*      */   }
/*      */ 
/*      */   public AppMeasurement()
/*      */   {
/*  338 */     AppMeasurement s = this;
/*      */ 
/*  341 */     s.requiredVarList = new String[] { "dynamicVariablePrefix", "visitorID", "charSet", "visitorNamespace", "pageName", "pageURL", "referrer", "currencyCode", "pe", "pev1", "pev2" };
/*      */ 
/*  356 */     s.accountVarList = new Vector();
/*      */ 
/*  358 */     s.copyArrayIntoVector(s.accountVarList, s.requiredVarList);
/*      */ 
/*  360 */     s.copyArrayIntoVector(s.accountVarList, new String[] { "purchaseID", "channel", "server", "pageType", "transactionID", "campaign", "state", "zip", "events", "products" });
/*      */ 
/*  373 */     for (int i = 1; i <= 5; i++) {
/*  374 */       s.accountVarList.addElement("hier" + i);
/*      */     }
/*      */ 
/*  377 */     for (int i = 1; i <= 50; i++) {
/*  378 */       s.accountVarList.addElement("prop" + i);
/*      */     }
/*      */ 
/*  381 */     for (int i = 1; i <= 50; i++) {
/*  382 */       s.accountVarList.addElement("eVar" + i);
/*      */     }
/*      */ 
/*  386 */     s.accountConfigList = new String[] { "linkURL", "linkName", "linkType", "linkTrackVars", "linkTrackEvents", "dc", "trackingServer", "trackingServerSecure", "userAgent" };
/*      */ 
/*  398 */     s.setupAccountVarConstants();
/*      */ 
/*  401 */     s.ssl = false;
/*  402 */     s.linkLeaveQueryString = false;
/*  403 */     s.debugTracking = false;
/*  404 */     s.usePlugins = false;
/*  405 */     s.userAgent = s.getDefaultUserAgent();
/*  406 */     s.visitorID = s.getDefaultVisitorID();
/*  407 */     s.charSet = s.getDefaultCharSet();
/*      */ 
/*  409 */     s.delegate = null;
/*  410 */     s.version = "JBB-1.0";
/*      */ 
/*  413 */     if (requestList == null)
/*  414 */       s.startRequestProcessor();
/*      */   }
/*      */ 
/*      */   public void track()
/*      */   {
/*  426 */     AppMeasurement s = this;
/*  427 */     s.track(null);
/*      */   }
/*      */ 
/*      */   public void track(Hashtable variableOverrides)
/*      */   {
/*  439 */     AppMeasurement s = this;
/*      */ 
/*  441 */     s.validateRequiredRequestVariables();
/*      */ 
/*  444 */     Random randomNumberGenerator = new Random();
/*  445 */     String cacheBusting = "s" + (int)Math.floor(randomNumberGenerator.nextDouble() * 100000000.0D);
/*      */ 
/*  448 */     String queryString = "t=" + s.escape(s.getFormattedTimestamp());
/*      */ 
/*  451 */     Hashtable variableOverridesBackup = null;
/*  452 */     if (variableOverrides != null) {
/*  453 */       variableOverridesBackup = new Hashtable();
/*  454 */       s.variableOverridesBuild(variableOverridesBackup);
/*  455 */       s.variableOverridesApply(variableOverrides);
/*      */     }
/*      */ 
/*  459 */     if ((s.usePlugins) && (s.delegate != null)) {
/*  460 */       s.delegate.doPlugins(s);
/*      */     }
/*      */ 
/*  464 */     if (s.isSet(s.account)) {
/*  465 */       s.handleLinkTracking();
/*  466 */       s.handleTechnology();
/*  467 */       queryString = queryString + s.getQueryString();
/*  468 */       s.makeRequest(cacheBusting, queryString);
/*      */     }
/*      */ 
/*  472 */     if (variableOverrides != null) {
/*  473 */       s.variableOverridesApply(variableOverridesBackup);
/*      */     }
/*      */ 
/*  477 */     s.referrer = null;
/*  478 */     s.pe = null;
/*  479 */     s.pev1 = null;
/*  480 */     s.pev2 = null;
/*  481 */     s.linkURL = null;
/*  482 */     s.linkName = null;
/*  483 */     s.linkType = null;
/*      */   }
/*      */ 
/*      */   public void trackLink(String linkURL, String linkType, String linkName)
/*      */   {
/*  497 */     AppMeasurement s = this;
/*      */ 
/*  499 */     s.linkURL = linkURL;
/*  500 */     s.linkType = linkType;
/*  501 */     s.linkName = linkName;
/*      */ 
/*  503 */     s.track();
/*      */   }
/*      */ 
/*      */   public void trackLink(String linkURL, String linkType, String linkName, Hashtable variableOverrides)
/*      */   {
/*  518 */     AppMeasurement s = this;
/*      */ 
/*  520 */     s.linkURL = linkURL;
/*  521 */     s.linkType = linkType;
/*  522 */     s.linkName = linkName;
/*      */ 
/*  524 */     s.track(variableOverrides);
/*      */   }
/*      */ 
/*      */   public void clearVars()
/*      */   {
/*  533 */     AppMeasurement s = this;
/*  534 */     String varKey = null;
/*  535 */     String varPrefix = null;
/*      */ 
/*  537 */     for (int i = 0; i < s.accountVarList.size(); i++) {
/*  538 */       varKey = (String)s.accountVarList.elementAt(i);
/*      */ 
/*  541 */       if (varKey.length() > 4)
/*  542 */         varPrefix = varKey.substring(0, 4);
/*      */       else {
/*  544 */         varPrefix = "";
/*      */       }
/*      */ 
/*  548 */       if ((!varKey.equals("channel")) && (!varKey.equals("events")) && (!varKey.equals("purchaseID")) && (!varKey.equals("transactionID")) && (!varKey.equals("products")) && (!varKey.equals("state")) && (!varKey.equals("zip")) && (!varKey.equals("campaign")) && (!varPrefix.equals("prop")) && (!varPrefix.equals("eVar")) && (!varPrefix.equals("hier")))
/*      */       {
/*      */         continue;
/*      */       }
/*      */ 
/*  560 */       s.setAccountVar(varKey, null);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void variableOverridesBuild(Hashtable variableOverrides)
/*      */   {
/*  569 */     AppMeasurement s = this;
/*      */ 
/*  571 */     String varKey = null;
/*  572 */     String antiKey = null;
/*  573 */     String varValue = null;
/*  574 */     String overrideValue = null;
/*  575 */     Object overrideValueObject = null;
/*      */ 
/*  577 */     for (int varNum = 0; varNum < s.accountVarList.size(); varNum++) {
/*  578 */       varKey = (String)s.accountVarList.elementAt(varNum);
/*  579 */       varValue = s.getAccountVar(varKey);
/*      */ 
/*  582 */       overrideValueObject = variableOverrides.get(varKey);
/*  583 */       if ((overrideValueObject != null) && (!(overrideValueObject instanceof String))) {
/*      */         continue;
/*      */       }
/*  586 */       overrideValue = (String)overrideValueObject;
/*      */ 
/*  589 */       if (!s.isSet(overrideValue)) {
/*  590 */         if (s.isSet(varValue)) {
/*  591 */           variableOverrides.put(varKey, varValue);
/*      */         } else {
/*  593 */           antiKey = "!" + varKey;
/*  594 */           variableOverrides.put(antiKey, "1");
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  599 */     for (int varNum = 0; varNum < s.accountConfigList.length; varNum++) {
/*  600 */       varKey = s.accountConfigList[varNum];
/*  601 */       varValue = s.getAccountVar(varKey);
/*      */ 
/*  604 */       overrideValueObject = variableOverrides.get(varKey);
/*  605 */       if ((overrideValueObject != null) && (!(overrideValueObject instanceof String))) {
/*      */         continue;
/*      */       }
/*  608 */       overrideValue = (String)overrideValueObject;
/*      */ 
/*  611 */       if (!s.isSet(overrideValue))
/*  612 */         if (s.isSet(varValue)) {
/*  613 */           variableOverrides.put(varKey, varValue);
/*      */         } else {
/*  615 */           antiKey = "!" + varKey;
/*  616 */           variableOverrides.put(antiKey, "1");
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void variableOverridesApply(Hashtable variableOverrides)
/*      */   {
/*  624 */     AppMeasurement s = this;
/*      */ 
/*  626 */     String varKey = null;
/*  627 */     String antiKey = null;
/*  628 */     String overrideValue = null;
/*  629 */     Object overrideValueObject = null;
/*      */ 
/*  631 */     for (int varNum = 0; varNum < s.accountVarList.size(); varNum++) {
/*  632 */       varKey = (String)s.accountVarList.elementAt(varNum);
/*  633 */       antiKey = '!' + varKey;
/*      */ 
/*  636 */       overrideValueObject = variableOverrides.get(varKey);
/*  637 */       if ((overrideValueObject != null) && (!(overrideValueObject instanceof String))) {
/*      */         continue;
/*      */       }
/*  640 */       overrideValue = (String)overrideValueObject;
/*      */ 
/*  642 */       if ((s.isSet(overrideValue)) || (s.isSet((String)variableOverrides.get(antiKey)))) {
/*  643 */         s.setAccountVar(varKey, overrideValue);
/*      */       }
/*      */     }
/*      */ 
/*  647 */     for (int varNum = 0; varNum < s.accountConfigList.length; varNum++) {
/*  648 */       varKey = s.accountConfigList[varNum];
/*  649 */       antiKey = '!' + varKey;
/*      */ 
/*  652 */       overrideValueObject = variableOverrides.get(varKey);
/*  653 */       if ((overrideValueObject != null) && (!(overrideValueObject instanceof String))) {
/*      */         continue;
/*      */       }
/*  656 */       overrideValue = (String)overrideValueObject;
/*      */ 
/*  658 */       if ((s.isSet(overrideValue)) || (s.isSet((String)variableOverrides.get(antiKey))))
/*  659 */         s.setAccountVar(varKey, overrideValue);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void handleLinkTracking()
/*      */   {
/*  666 */     AppMeasurement s = this;
/*      */ 
/*  668 */     String linkType = s.linkType;
/*  669 */     String linkURL = s.linkURL;
/*  670 */     String linkName = s.linkName;
/*      */ 
/*  672 */     if ((s.isSet(linkType)) && ((s.isSet(linkURL)) || (s.isSet(linkName)))) {
/*  673 */       linkType = linkType.toLowerCase();
/*      */ 
/*  676 */       if ((!linkType.equals("d")) && (!linkType.equals("e"))) {
/*  677 */         linkType = "o";
/*      */       }
/*      */ 
/*  681 */       if ((s.isSet(linkURL)) && (!s.linkLeaveQueryString)) {
/*  682 */         int queryStringStart = linkURL.indexOf('?');
/*  683 */         if (queryStringStart != -1) {
/*  684 */           linkURL = linkURL.substring(0, queryStringStart);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  689 */       s.pe = ("lnk_" + s.escape(linkType));
/*  690 */       s.pev1 = s.escape(linkURL);
/*  691 */       s.pev2 = s.escape(linkName);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void handleTechnology()
/*      */   {
/*      */   }
/*      */ 
/*      */   private String getQueryString()
/*      */   {
/*  714 */     AppMeasurement s = this;
/*      */ 
/*  716 */     String queryString = "";
/*  717 */     String varKey = null;
/*  718 */     String varValue = null;
/*  719 */     String[] varValueParts = null;
/*  720 */     String varPrefix = null;
/*  721 */     String varSuffix = null;
/*  722 */     String varFilter = null;
/*  723 */     String eventFilter = null;
/*      */ 
/*  726 */     if (s.isSet(s.linkType)) {
/*  727 */       varFilter = s.linkTrackVars;
/*  728 */       eventFilter = s.linkTrackEvents;
/*      */     }
/*      */ 
/*  731 */     if (s.isSet(varFilter)) {
/*  732 */       String[] technologyVarList = new String[0];
/*  733 */       varFilter = ',' + varFilter + ',' + s.joinArray(s.requiredVarList, ",") + ',' + s.joinArray(technologyVarList, ",") + ',';
/*      */     }
/*  735 */     if (s.isSet(eventFilter)) {
/*  736 */       eventFilter = ',' + eventFilter + ',';
/*      */     }
/*      */ 
/*  740 */     for (int varNum = 0; varNum < s.accountVarList.size(); varNum++) {
/*  741 */       varKey = (String)s.accountVarList.elementAt(varNum);
/*  742 */       varValue = s.getAccountVar(varKey);
/*      */ 
/*  744 */       if (varKey.length() > 4) {
/*  745 */         varPrefix = varKey.substring(0, 4);
/*  746 */         varSuffix = varKey.substring(4);
/*      */       } else {
/*  748 */         varPrefix = null;
/*  749 */         varSuffix = null;
/*      */       }
/*      */ 
/*  752 */       if (!s.isSet(varValue)) {
/*      */         continue;
/*      */       }
/*  755 */       String varFilterCheck = ',' + varKey + ',';
/*  756 */       if ((s.isSet(varFilter)) && (varFilter.indexOf(varFilterCheck) == -1))
/*      */       {
/*      */         continue;
/*      */       }
/*      */ 
/*  761 */       if (varKey.equals("dynamicVariablePrefix"))
/*  762 */         varKey = "D";
/*  763 */       else if (varKey.equals("visitorID"))
/*  764 */         varKey = "vid";
/*  765 */       else if (varKey.equals("pageURL"))
/*  766 */         varKey = "g";
/*  767 */       else if (varKey.equals("referrer"))
/*  768 */         varKey = "r";
/*  769 */       else if (varKey.equals("charSet"))
/*  770 */         varKey = "ce";
/*  771 */       else if (varKey.equals("visitorNamespace"))
/*  772 */         varKey = "ns";
/*  773 */       else if (varKey.equals("currencyCode"))
/*  774 */         varKey = "cc";
/*  775 */       else if (varKey.equals("channel"))
/*  776 */         varKey = "ch";
/*  777 */       else if (varKey.equals("transactionID"))
/*  778 */         varKey = "xact";
/*  779 */       else if (varKey.equals("campaign"))
/*  780 */         varKey = "v0";
/*  781 */       else if (varKey.equals("events"))
/*      */       {
/*  783 */         if (s.isSet(eventFilter)) {
/*  784 */           varValueParts = s.splitString(",", varValue);
/*  785 */           String validEvents = "";
/*  786 */           for (int varSubNum = 0; varSubNum < varValueParts.length; varSubNum++) {
/*  787 */             String eventFilterCheck = ',' + varValueParts[varSubNum] + ',';
/*  788 */             if (eventFilter.indexOf(eventFilterCheck) != -1) {
/*  789 */               validEvents = validEvents + (s.isSet(validEvents) ? "," : "") + varValueParts[varSubNum];
/*      */             }
/*      */           }
/*  792 */           varValue = validEvents;
/*      */         }
/*  794 */       } else if (s.isNumber(varSuffix)) {
/*  795 */         if (varPrefix.equals("prop")) {
/*  796 */           varKey = 'c' + varSuffix;
/*  797 */         } else if (varPrefix.equals("eVar")) {
/*  798 */           varKey = 'v' + varSuffix;
/*  799 */         } else if (varPrefix.equals("hier")) {
/*  800 */           varKey = 'h' + varSuffix;
/*  801 */           if (varValue.length() > 255) {
/*  802 */             varValue = varValue.substring(0, 255);
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  808 */       if (s.isSet(varValue)) {
/*  809 */         queryString = queryString + '&' + s.escape(varKey) + '=' + ((varKey.length() > 3) && (varKey.substring(0, 3).equals("pev")) ? varValue : s.escape(varValue));
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  814 */     return queryString;
/*      */   }
/*      */ 
/*      */   private void makeRequest(String cacheBusting, String queryString)
/*      */   {
/*  819 */     AppMeasurement s = this;
/*  820 */     String trackingServer = s.trackingServer;
/*  821 */     String prefix = s.visitorNamespace;
/*  822 */     String dc = s.dc;
/*      */ 
/*  825 */     if (!s.isSet(trackingServer))
/*      */     {
/*  828 */       if (!s.isSet(prefix)) {
/*  829 */         prefix = s.account;
/*      */ 
/*  832 */         int firstComma = prefix.indexOf(',');
/*  833 */         if (firstComma != -1) {
/*  834 */           prefix = prefix.substring(0, firstComma);
/*      */         }
/*      */ 
/*  838 */         prefix = prefix.replace('_', '-').replace('.', '-');
/*      */       }
/*      */ 
/*  842 */       if (s.isSet(dc)) {
/*  843 */         dc = dc.toLowerCase();
/*  844 */         if ((dc.equals("dc2")) || (dc.equals("122")))
/*  845 */           dc = "122";
/*      */         else
/*  847 */           dc = "112";
/*      */       }
/*      */       else {
/*  850 */         dc = "112";
/*      */       }
/*      */ 
/*  853 */       trackingServer = prefix + '.' + dc + ".2o7.net";
/*  854 */     } else if ((s.ssl) && (s.isSet(s.trackingServerSecure))) {
/*  855 */       trackingServer = s.trackingServerSecure;
/*      */     }
/*      */ 
/*  859 */     String requestProtocol = s.ssl ? "https" : "http";
/*  860 */     String requestString = requestProtocol + "://" + trackingServer + "/b/ss/" + s.account + '/' + s.version + '/' + cacheBusting + "?AQB=1&ndh=1&" + queryString + "&AQE=1";
/*  861 */     Request request = new Request(requestString, s.userAgent, s.getCurrentLocaleID());
/*      */ 
/*  864 */     synchronized (requestList) {
/*  865 */       requestList.addElement(request);
/*  866 */       requestList.notify();
/*      */     }
/*      */ 
/*  870 */     if (s.debugTracking)
/*  871 */       s.logRequest(requestString);
/*      */   }
/*      */ 
/*      */   private void startRequestProcessor()
/*      */   {
/*  877 */     requestList = new Vector();
/*      */ 
/*  879 */     Thread requestProcessor = new Thread()
/*      */     {
/*      */       public void run() {
/*      */         while (true) {
/*  883 */           synchronized (AppMeasurement.requestList) {
/*  884 */             if (!AppMeasurement.requestList.isEmpty()) continue;
/*      */             try {
/*  886 */               AppMeasurement.requestList.wait();
/*      */             } catch (InterruptedException ignored) {
/*      */             }
/*  889 */             continue;
/*      */ 
/*  891 */             Request request = (Request)AppMeasurement.requestList.firstElement();
/*  892 */             AppMeasurement.requestList.removeElementAt(0);
/*      */           }
/*      */           Request request;
/*  894 */           request.send();
/*      */         }
/*      */       }
/*      */     };
/*  899 */     requestProcessor.start();
/*      */   }
/*      */ 
/*      */   private String getFormattedTimestamp()
/*      */   {
/*  904 */     Calendar calendar = Calendar.getInstance();
/*      */ 
/*  906 */     return calendar.get(5) + "/" + calendar.get(2) + "/" + calendar.get(1) + " " + calendar.get(11) + ":" + calendar.get(12) + ":" + calendar.get(13) + " " + (calendar.get(7) - 1) + " " + calendar.getTimeZone().getRawOffset() / 60000 * -1;
/*      */   }
/*      */ 
/*      */   private String getDefaultCharSet()
/*      */   {
/*  918 */     return "UTF-8";
/*      */   }
/*      */ 
/*      */   private void validateRequiredRequestVariables()
/*      */   {
/*  923 */     AppMeasurement s = this;
/*      */ 
/*  930 */     if (!s.isSet(s.userAgent)) {
/*  931 */       s.userAgent = s.getDefaultUserAgent();
/*      */     }
/*      */ 
/*  934 */     if (!s.isSet(s.visitorID)) {
/*  935 */       s.visitorID = s.getDefaultVisitorID();
/*      */     }
/*      */ 
/*  938 */     if (!s.isSet(s.charSet))
/*  939 */       s.charSet = s.getDefaultCharSet();
/*      */   }
/*      */ 
/*      */   private boolean isSet(String var)
/*      */   {
/*  945 */     return (var != null) && (var.length() > 0);
/*      */   }
/*      */ 
/*      */   private boolean isNumber(String value)
/*      */   {
/*      */     try
/*      */     {
/*  952 */       Integer.parseInt(value);
/*  953 */       return true; } catch (Exception e) {
/*      */     }
/*  955 */     return false;
/*      */   }
/*      */ 
/*      */   private String escape(String unescapedString)
/*      */   {
/*  961 */     AppMeasurement s = this;
/*      */ 
/*  964 */     if (unescapedString == null) {
/*  965 */       return null;
/*      */     }
/*      */ 
/*  968 */     String escapedString = "";
/*      */     try
/*      */     {
/*  972 */       unescapedString = new String(unescapedString.getBytes(s.getDefaultCharSet()));
/*      */     } catch (UnsupportedEncodingException e) {
/*  974 */       return "";
/*      */     }
/*      */ 
/*  977 */     int length = unescapedString.length();
/*  978 */     for (int i = 0; i < length; i++) {
/*  979 */       char c = unescapedString.charAt(i);
/*  980 */       if ((c <= ')') || ((c >= '+') && (c <= ',')) || (c == '/') || ((c >= ':') && (c <= '?')) || ((c >= '[') && (c <= '^')) || (c == '`') || ((c >= '{') && (c <= '}')) || (c >= '') || (c == ';'))
/*      */       {
/*  987 */         String hexValue = Integer.toString(c, 16).toUpperCase();
/*  988 */         if (hexValue.length() == 1) {
/*  989 */           hexValue = '0' + hexValue;
/*      */         }
/*  991 */         escapedString = escapedString + '%' + hexValue;
/*      */       }
/*      */       else {
/*  994 */         escapedString = escapedString + c;
/*      */       }
/*      */     }
/*      */ 
/*  998 */     return escapedString;
/*      */   }
/*      */ 
/*      */   private String unescape(String escapedString)
/*      */   {
/* 1005 */     AppMeasurement s = this;
/*      */ 
/* 1008 */     if (escapedString == null) {
/* 1009 */       return null;
/*      */     }
/*      */     try
/*      */     {
/* 1013 */       String unescapedString = "";
/*      */ 
/* 1015 */       int escapedStringLength = escapedString.length();
/* 1016 */       int i = 0;
/* 1017 */       while (i < escapedStringLength) {
/* 1018 */         char c = escapedString.charAt(i);
/* 1019 */         if (c == '%') {
/* 1020 */           String hexValue = escapedString.substring(i + 1, i + 3);
/* 1021 */           unescapedString = unescapedString + (char)Integer.parseInt(hexValue, 16);
/* 1022 */           i += 3;
/*      */         } else {
/* 1024 */           unescapedString = unescapedString + c;
/* 1025 */           i++;
/*      */         }
/*      */       }
/* 1028 */       return new String(unescapedString.getBytes(), s.getDefaultCharSet());
/*      */     } catch (UnsupportedEncodingException e) {
/* 1030 */       return ""; } catch (IndexOutOfBoundsException e) {
/*      */     }
/* 1032 */     return "";
/*      */   }
/*      */ 
/*      */   private String joinArray(String[] array, String delimiter)
/*      */   {
/* 1038 */     String joinedValue = "";
/* 1039 */     boolean isFirstValue = true;
/* 1040 */     for (int i = 0; i < array.length; i++) {
/* 1041 */       if (!isFirstValue) {
/* 1042 */         joinedValue = joinedValue + delimiter;
/*      */       }
/* 1044 */       joinedValue = joinedValue + array[i];
/* 1045 */       isFirstValue = false;
/*      */     }
/* 1047 */     return joinedValue;
/*      */   }
/*      */ 
/*      */   private void logRequest(String requestString)
/*      */   {
/* 1052 */     AppMeasurement s = this;
/*      */ 
/* 1054 */     String debugString = requestString;
/* 1055 */     String[] requestComponents = s.splitString("&", requestString);
/* 1056 */     for (int i = 0; i < requestComponents.length; i++) {
/* 1057 */       debugString = debugString + "\n\t" + s.unescape(requestComponents[i]);
/*      */     }
/*      */ 
/* 1060 */     s.log("\nOmniture App Measurement Debug: " + debugString);
/*      */   }
/*      */ 
/*      */   private void log(String message)
/*      */   {
/* 1067 */     AppMeasurement s = this;
/* 1068 */     if (s.debugTracking)
/* 1069 */       System.out.println(message);
/*      */   }
/*      */ 
/*      */   private String getDefaultUserAgent()
/*      */   {
/* 1075 */     AppMeasurement s = this;
/* 1076 */     return "BlackBerry" + DeviceInfo.getDeviceName() + " " + s.getApplicationID();
/*      */   }
/*      */ 
/*      */   private String getDefaultVisitorID()
/*      */   {
/* 1087 */     return "" + DeviceInfo.getDeviceId();
/*      */   }
/*      */ 
/*      */   private String getCurrentLocaleID()
/*      */   {
/* 1092 */     Locale currentLocale = Locale.getDefaultForSystem();
/* 1093 */     return currentLocale.getLanguage() + '-' + currentLocale.getCountry().toLowerCase();
/*      */   }
/*      */ 
/*      */   private String getApplicationID()
/*      */   {
/* 1098 */     ApplicationDescriptor application = ApplicationDescriptor.currentApplicationDescriptor();
/* 1099 */     return application.getName() + "/" + application.getVersion();
/*      */   }
/*      */ 
/*      */   private String[] splitString(String delimiter, String str)
/*      */   {
/* 1108 */     int idx = 0;
/* 1109 */     int cnt = 1;
/* 1110 */     while ((idx = str.indexOf(delimiter, idx)) >= 0) {
/* 1111 */       cnt++;
/* 1112 */       idx += delimiter.length();
/*      */     }
/*      */ 
/* 1115 */     String[] ret = new String[cnt];
/*      */ 
/* 1118 */     if (cnt == 1) { ret[0] = str;
/*      */     } else {
/* 1120 */       cnt = 0;
/* 1121 */       while ((idx = str.indexOf(delimiter)) >= 0) {
/* 1122 */         ret[(cnt++)] = str.substring(0, idx);
/* 1123 */         str = str.substring(idx + delimiter.length());
/*      */       }
/* 1125 */       ret[cnt] = str;
/*      */     }
/*      */ 
/* 1128 */     return ret;
/*      */   }
/*      */ 
/*      */   private void copyArrayIntoVector(Vector vector, String[] array)
/*      */   {
/* 1134 */     for (int i = 0; i < array.length; i++)
/* 1135 */       vector.addElement(array[i]);
/*      */   }
/*      */ 
/*      */   private void setupAccountVarConstants()
/*      */   {
/* 1141 */     AppMeasurement s = this;
/*      */ 
/* 1144 */     s.accountVarConstants = new Hashtable();
/*      */ 
/* 1147 */     s.accountVarConstants.put("account", new Integer(1));
/* 1148 */     s.accountVarConstants.put("linkURL", new Integer(2));
/* 1149 */     s.accountVarConstants.put("linkName", new Integer(3));
/* 1150 */     s.accountVarConstants.put("linkType", new Integer(4));
/* 1151 */     s.accountVarConstants.put("linkTrackVars", new Integer(5));
/* 1152 */     s.accountVarConstants.put("linkTrackEvents", new Integer(6));
/* 1153 */     s.accountVarConstants.put("dc", new Integer(7));
/* 1154 */     s.accountVarConstants.put("trackingServer", new Integer(8));
/* 1155 */     s.accountVarConstants.put("trackingServerSecure", new Integer(9));
/* 1156 */     s.accountVarConstants.put("userAgent", new Integer(10));
/* 1157 */     s.accountVarConstants.put("dynamicVariablePrefix", new Integer(11));
/* 1158 */     s.accountVarConstants.put("visitorID", new Integer(12));
/* 1159 */     s.accountVarConstants.put("charSet", new Integer(13));
/* 1160 */     s.accountVarConstants.put("visitorNamespace", new Integer(14));
/* 1161 */     s.accountVarConstants.put("pageName", new Integer(15));
/* 1162 */     s.accountVarConstants.put("pageURL", new Integer(16));
/* 1163 */     s.accountVarConstants.put("referrer", new Integer(17));
/* 1164 */     s.accountVarConstants.put("currencyCode", new Integer(18));
/* 1165 */     s.accountVarConstants.put("purchaseID", new Integer(19));
/* 1166 */     s.accountVarConstants.put("channel", new Integer(20));
/* 1167 */     s.accountVarConstants.put("server", new Integer(21));
/* 1168 */     s.accountVarConstants.put("pageType", new Integer(22));
/* 1169 */     s.accountVarConstants.put("transactionID", new Integer(23));
/* 1170 */     s.accountVarConstants.put("campaign", new Integer(24));
/* 1171 */     s.accountVarConstants.put("state", new Integer(25));
/* 1172 */     s.accountVarConstants.put("zip", new Integer(26));
/* 1173 */     s.accountVarConstants.put("events", new Integer(27));
/* 1174 */     s.accountVarConstants.put("products", new Integer(28));
/* 1175 */     s.accountVarConstants.put("hier1", new Integer(29));
/* 1176 */     s.accountVarConstants.put("hier2", new Integer(30));
/* 1177 */     s.accountVarConstants.put("hier3", new Integer(31));
/* 1178 */     s.accountVarConstants.put("hier4", new Integer(32));
/* 1179 */     s.accountVarConstants.put("hier5", new Integer(33));
/* 1180 */     s.accountVarConstants.put("prop1", new Integer(34));
/* 1181 */     s.accountVarConstants.put("prop2", new Integer(35));
/* 1182 */     s.accountVarConstants.put("prop3", new Integer(36));
/* 1183 */     s.accountVarConstants.put("prop4", new Integer(37));
/* 1184 */     s.accountVarConstants.put("prop5", new Integer(38));
/* 1185 */     s.accountVarConstants.put("prop6", new Integer(39));
/* 1186 */     s.accountVarConstants.put("prop7", new Integer(40));
/* 1187 */     s.accountVarConstants.put("prop8", new Integer(41));
/* 1188 */     s.accountVarConstants.put("prop9", new Integer(42));
/* 1189 */     s.accountVarConstants.put("prop10", new Integer(43));
/* 1190 */     s.accountVarConstants.put("prop11", new Integer(44));
/* 1191 */     s.accountVarConstants.put("prop12", new Integer(45));
/* 1192 */     s.accountVarConstants.put("prop13", new Integer(46));
/* 1193 */     s.accountVarConstants.put("prop14", new Integer(47));
/* 1194 */     s.accountVarConstants.put("prop15", new Integer(48));
/* 1195 */     s.accountVarConstants.put("prop16", new Integer(49));
/* 1196 */     s.accountVarConstants.put("prop17", new Integer(50));
/* 1197 */     s.accountVarConstants.put("prop18", new Integer(51));
/* 1198 */     s.accountVarConstants.put("prop19", new Integer(52));
/* 1199 */     s.accountVarConstants.put("prop20", new Integer(53));
/* 1200 */     s.accountVarConstants.put("prop21", new Integer(54));
/* 1201 */     s.accountVarConstants.put("prop22", new Integer(55));
/* 1202 */     s.accountVarConstants.put("prop23", new Integer(56));
/* 1203 */     s.accountVarConstants.put("prop24", new Integer(57));
/* 1204 */     s.accountVarConstants.put("prop25", new Integer(58));
/* 1205 */     s.accountVarConstants.put("prop26", new Integer(59));
/* 1206 */     s.accountVarConstants.put("prop27", new Integer(60));
/* 1207 */     s.accountVarConstants.put("prop28", new Integer(61));
/* 1208 */     s.accountVarConstants.put("prop29", new Integer(62));
/* 1209 */     s.accountVarConstants.put("prop30", new Integer(63));
/* 1210 */     s.accountVarConstants.put("prop31", new Integer(64));
/* 1211 */     s.accountVarConstants.put("prop32", new Integer(65));
/* 1212 */     s.accountVarConstants.put("prop33", new Integer(66));
/* 1213 */     s.accountVarConstants.put("prop34", new Integer(67));
/* 1214 */     s.accountVarConstants.put("prop35", new Integer(68));
/* 1215 */     s.accountVarConstants.put("prop36", new Integer(69));
/* 1216 */     s.accountVarConstants.put("prop37", new Integer(70));
/* 1217 */     s.accountVarConstants.put("prop38", new Integer(71));
/* 1218 */     s.accountVarConstants.put("prop39", new Integer(72));
/* 1219 */     s.accountVarConstants.put("prop40", new Integer(73));
/* 1220 */     s.accountVarConstants.put("prop41", new Integer(74));
/* 1221 */     s.accountVarConstants.put("prop42", new Integer(75));
/* 1222 */     s.accountVarConstants.put("prop43", new Integer(76));
/* 1223 */     s.accountVarConstants.put("prop44", new Integer(77));
/* 1224 */     s.accountVarConstants.put("prop45", new Integer(78));
/* 1225 */     s.accountVarConstants.put("prop46", new Integer(79));
/* 1226 */     s.accountVarConstants.put("prop47", new Integer(80));
/* 1227 */     s.accountVarConstants.put("prop48", new Integer(81));
/* 1228 */     s.accountVarConstants.put("prop49", new Integer(82));
/* 1229 */     s.accountVarConstants.put("prop50", new Integer(83));
/* 1230 */     s.accountVarConstants.put("eVar1", new Integer(84));
/* 1231 */     s.accountVarConstants.put("eVar2", new Integer(85));
/* 1232 */     s.accountVarConstants.put("eVar3", new Integer(86));
/* 1233 */     s.accountVarConstants.put("eVar4", new Integer(87));
/* 1234 */     s.accountVarConstants.put("eVar5", new Integer(88));
/* 1235 */     s.accountVarConstants.put("eVar6", new Integer(89));
/* 1236 */     s.accountVarConstants.put("eVar7", new Integer(90));
/* 1237 */     s.accountVarConstants.put("eVar8", new Integer(91));
/* 1238 */     s.accountVarConstants.put("eVar9", new Integer(92));
/* 1239 */     s.accountVarConstants.put("eVar10", new Integer(93));
/* 1240 */     s.accountVarConstants.put("eVar11", new Integer(94));
/* 1241 */     s.accountVarConstants.put("eVar12", new Integer(95));
/* 1242 */     s.accountVarConstants.put("eVar13", new Integer(96));
/* 1243 */     s.accountVarConstants.put("eVar14", new Integer(97));
/* 1244 */     s.accountVarConstants.put("eVar15", new Integer(98));
/* 1245 */     s.accountVarConstants.put("eVar16", new Integer(99));
/* 1246 */     s.accountVarConstants.put("eVar17", new Integer(100));
/* 1247 */     s.accountVarConstants.put("eVar18", new Integer(101));
/* 1248 */     s.accountVarConstants.put("eVar19", new Integer(102));
/* 1249 */     s.accountVarConstants.put("eVar20", new Integer(103));
/* 1250 */     s.accountVarConstants.put("eVar21", new Integer(104));
/* 1251 */     s.accountVarConstants.put("eVar22", new Integer(105));
/* 1252 */     s.accountVarConstants.put("eVar23", new Integer(106));
/* 1253 */     s.accountVarConstants.put("eVar24", new Integer(107));
/* 1254 */     s.accountVarConstants.put("eVar25", new Integer(108));
/* 1255 */     s.accountVarConstants.put("eVar26", new Integer(109));
/* 1256 */     s.accountVarConstants.put("eVar27", new Integer(110));
/* 1257 */     s.accountVarConstants.put("eVar28", new Integer(111));
/* 1258 */     s.accountVarConstants.put("eVar29", new Integer(112));
/* 1259 */     s.accountVarConstants.put("eVar30", new Integer(113));
/* 1260 */     s.accountVarConstants.put("eVar31", new Integer(114));
/* 1261 */     s.accountVarConstants.put("eVar32", new Integer(115));
/* 1262 */     s.accountVarConstants.put("eVar33", new Integer(116));
/* 1263 */     s.accountVarConstants.put("eVar34", new Integer(117));
/* 1264 */     s.accountVarConstants.put("eVar35", new Integer(118));
/* 1265 */     s.accountVarConstants.put("eVar36", new Integer(119));
/* 1266 */     s.accountVarConstants.put("eVar37", new Integer(120));
/* 1267 */     s.accountVarConstants.put("eVar38", new Integer(121));
/* 1268 */     s.accountVarConstants.put("eVar39", new Integer(122));
/* 1269 */     s.accountVarConstants.put("eVar40", new Integer(123));
/* 1270 */     s.accountVarConstants.put("eVar41", new Integer(124));
/* 1271 */     s.accountVarConstants.put("eVar42", new Integer(125));
/* 1272 */     s.accountVarConstants.put("eVar43", new Integer(126));
/* 1273 */     s.accountVarConstants.put("eVar44", new Integer(127));
/* 1274 */     s.accountVarConstants.put("eVar45", new Integer(128));
/* 1275 */     s.accountVarConstants.put("eVar46", new Integer(129));
/* 1276 */     s.accountVarConstants.put("eVar47", new Integer(130));
/* 1277 */     s.accountVarConstants.put("eVar48", new Integer(131));
/* 1278 */     s.accountVarConstants.put("eVar49", new Integer(132));
/* 1279 */     s.accountVarConstants.put("eVar50", new Integer(133));
/* 1280 */     s.accountVarConstants.put("pe", new Integer(134));
/* 1281 */     s.accountVarConstants.put("pev1", new Integer(135));
/* 1282 */     s.accountVarConstants.put("pev2", new Integer(136));
/*      */   }
/*      */ 
/*      */   private int getAccountVarConstant(String key)
/*      */   {
/* 1287 */     AppMeasurement s = this;
/* 1288 */     Integer i = (Integer)s.accountVarConstants.get(key);
/* 1289 */     return i.intValue();
/*      */   }
/*      */ 
/*      */   private String getAccountVar(String key)
/*      */   {
/* 1294 */     AppMeasurement s = this;
/*      */ 
/* 1296 */     switch (s.getAccountVarConstant(key)) {
/*      */     case 1:
/* 1298 */       return s.account;
/*      */     case 2:
/* 1301 */       return s.linkURL;
/*      */     case 3:
/* 1304 */       return s.linkName;
/*      */     case 4:
/* 1307 */       return s.linkType;
/*      */     case 5:
/* 1310 */       return s.linkTrackVars;
/*      */     case 6:
/* 1313 */       return s.linkTrackEvents;
/*      */     case 7:
/* 1316 */       return s.dc;
/*      */     case 8:
/* 1319 */       return s.trackingServer;
/*      */     case 9:
/* 1322 */       return s.trackingServerSecure;
/*      */     case 10:
/* 1325 */       return s.userAgent;
/*      */     case 11:
/* 1328 */       return s.dynamicVariablePrefix;
/*      */     case 12:
/* 1331 */       return s.visitorID;
/*      */     case 13:
/* 1334 */       return s.charSet;
/*      */     case 14:
/* 1337 */       return s.visitorNamespace;
/*      */     case 15:
/* 1340 */       return s.pageName;
/*      */     case 16:
/* 1343 */       return s.pageURL;
/*      */     case 17:
/* 1346 */       return s.referrer;
/*      */     case 18:
/* 1349 */       return s.currencyCode;
/*      */     case 19:
/* 1352 */       return s.purchaseID;
/*      */     case 20:
/* 1355 */       return s.channel;
/*      */     case 21:
/* 1358 */       return s.server;
/*      */     case 22:
/* 1361 */       return s.pageType;
/*      */     case 23:
/* 1364 */       return s.transactionID;
/*      */     case 24:
/* 1367 */       return s.campaign;
/*      */     case 25:
/* 1370 */       return s.state;
/*      */     case 26:
/* 1373 */       return s.zip;
/*      */     case 27:
/* 1376 */       return s.events;
/*      */     case 28:
/* 1379 */       return s.products;
/*      */     case 29:
/* 1382 */       return s.hier1;
/*      */     case 30:
/* 1385 */       return s.hier2;
/*      */     case 31:
/* 1388 */       return s.hier3;
/*      */     case 32:
/* 1391 */       return s.hier4;
/*      */     case 33:
/* 1394 */       return s.hier5;
/*      */     case 34:
/* 1397 */       return s.prop1;
/*      */     case 35:
/* 1400 */       return s.prop2;
/*      */     case 36:
/* 1403 */       return s.prop3;
/*      */     case 37:
/* 1406 */       return s.prop4;
/*      */     case 38:
/* 1409 */       return s.prop5;
/*      */     case 39:
/* 1412 */       return s.prop6;
/*      */     case 40:
/* 1415 */       return s.prop7;
/*      */     case 41:
/* 1418 */       return s.prop8;
/*      */     case 42:
/* 1421 */       return s.prop9;
/*      */     case 43:
/* 1424 */       return s.prop10;
/*      */     case 44:
/* 1427 */       return s.prop11;
/*      */     case 45:
/* 1430 */       return s.prop12;
/*      */     case 46:
/* 1433 */       return s.prop13;
/*      */     case 47:
/* 1436 */       return s.prop14;
/*      */     case 48:
/* 1439 */       return s.prop15;
/*      */     case 49:
/* 1442 */       return s.prop16;
/*      */     case 50:
/* 1445 */       return s.prop17;
/*      */     case 51:
/* 1448 */       return s.prop18;
/*      */     case 52:
/* 1451 */       return s.prop19;
/*      */     case 53:
/* 1454 */       return s.prop20;
/*      */     case 54:
/* 1457 */       return s.prop21;
/*      */     case 55:
/* 1460 */       return s.prop22;
/*      */     case 56:
/* 1463 */       return s.prop23;
/*      */     case 57:
/* 1466 */       return s.prop24;
/*      */     case 58:
/* 1469 */       return s.prop25;
/*      */     case 59:
/* 1472 */       return s.prop26;
/*      */     case 60:
/* 1475 */       return s.prop27;
/*      */     case 61:
/* 1478 */       return s.prop28;
/*      */     case 62:
/* 1481 */       return s.prop29;
/*      */     case 63:
/* 1484 */       return s.prop30;
/*      */     case 64:
/* 1487 */       return s.prop31;
/*      */     case 65:
/* 1490 */       return s.prop32;
/*      */     case 66:
/* 1493 */       return s.prop33;
/*      */     case 67:
/* 1496 */       return s.prop34;
/*      */     case 68:
/* 1499 */       return s.prop35;
/*      */     case 69:
/* 1502 */       return s.prop36;
/*      */     case 70:
/* 1505 */       return s.prop37;
/*      */     case 71:
/* 1508 */       return s.prop38;
/*      */     case 72:
/* 1511 */       return s.prop39;
/*      */     case 73:
/* 1514 */       return s.prop40;
/*      */     case 74:
/* 1517 */       return s.prop41;
/*      */     case 75:
/* 1520 */       return s.prop42;
/*      */     case 76:
/* 1523 */       return s.prop43;
/*      */     case 77:
/* 1526 */       return s.prop44;
/*      */     case 78:
/* 1529 */       return s.prop45;
/*      */     case 79:
/* 1532 */       return s.prop46;
/*      */     case 80:
/* 1535 */       return s.prop47;
/*      */     case 81:
/* 1538 */       return s.prop48;
/*      */     case 82:
/* 1541 */       return s.prop49;
/*      */     case 83:
/* 1544 */       return s.prop50;
/*      */     case 84:
/* 1547 */       return s.eVar1;
/*      */     case 85:
/* 1550 */       return s.eVar2;
/*      */     case 86:
/* 1553 */       return s.eVar3;
/*      */     case 87:
/* 1556 */       return s.eVar4;
/*      */     case 88:
/* 1559 */       return s.eVar5;
/*      */     case 89:
/* 1562 */       return s.eVar6;
/*      */     case 90:
/* 1565 */       return s.eVar7;
/*      */     case 91:
/* 1568 */       return s.eVar8;
/*      */     case 92:
/* 1571 */       return s.eVar9;
/*      */     case 93:
/* 1574 */       return s.eVar10;
/*      */     case 94:
/* 1577 */       return s.eVar11;
/*      */     case 95:
/* 1580 */       return s.eVar12;
/*      */     case 96:
/* 1583 */       return s.eVar13;
/*      */     case 97:
/* 1586 */       return s.eVar14;
/*      */     case 98:
/* 1589 */       return s.eVar15;
/*      */     case 99:
/* 1592 */       return s.eVar16;
/*      */     case 100:
/* 1595 */       return s.eVar17;
/*      */     case 101:
/* 1598 */       return s.eVar18;
/*      */     case 102:
/* 1601 */       return s.eVar19;
/*      */     case 103:
/* 1604 */       return s.eVar20;
/*      */     case 104:
/* 1607 */       return s.eVar21;
/*      */     case 105:
/* 1610 */       return s.eVar22;
/*      */     case 106:
/* 1613 */       return s.eVar23;
/*      */     case 107:
/* 1616 */       return s.eVar24;
/*      */     case 108:
/* 1619 */       return s.eVar25;
/*      */     case 109:
/* 1622 */       return s.eVar26;
/*      */     case 110:
/* 1625 */       return s.eVar27;
/*      */     case 111:
/* 1628 */       return s.eVar28;
/*      */     case 112:
/* 1631 */       return s.eVar29;
/*      */     case 113:
/* 1634 */       return s.eVar30;
/*      */     case 114:
/* 1637 */       return s.eVar31;
/*      */     case 115:
/* 1640 */       return s.eVar32;
/*      */     case 116:
/* 1643 */       return s.eVar33;
/*      */     case 117:
/* 1646 */       return s.eVar34;
/*      */     case 118:
/* 1649 */       return s.eVar35;
/*      */     case 119:
/* 1652 */       return s.eVar36;
/*      */     case 120:
/* 1655 */       return s.eVar37;
/*      */     case 121:
/* 1658 */       return s.eVar38;
/*      */     case 122:
/* 1661 */       return s.eVar39;
/*      */     case 123:
/* 1664 */       return s.eVar40;
/*      */     case 124:
/* 1667 */       return s.eVar41;
/*      */     case 125:
/* 1670 */       return s.eVar42;
/*      */     case 126:
/* 1673 */       return s.eVar43;
/*      */     case 127:
/* 1676 */       return s.eVar44;
/*      */     case 128:
/* 1679 */       return s.eVar45;
/*      */     case 129:
/* 1682 */       return s.eVar46;
/*      */     case 130:
/* 1685 */       return s.eVar47;
/*      */     case 131:
/* 1688 */       return s.eVar48;
/*      */     case 132:
/* 1691 */       return s.eVar49;
/*      */     case 133:
/* 1694 */       return s.eVar50;
/*      */     case 134:
/* 1697 */       return s.pe;
/*      */     case 135:
/* 1700 */       return s.pev1;
/*      */     case 136:
/* 1703 */       return s.pev2;
/*      */     }
/*      */ 
/* 1706 */     return null;
/*      */   }
/*      */ 
/*      */   private void setAccountVar(String key, String value)
/*      */   {
/* 1711 */     AppMeasurement s = this;
/*      */ 
/* 1713 */     switch (s.getAccountVarConstant(key)) {
/*      */     case 1:
/* 1715 */       s.account = value;
/* 1716 */       break;
/*      */     case 2:
/* 1719 */       s.linkURL = value;
/* 1720 */       break;
/*      */     case 3:
/* 1723 */       s.linkName = value;
/* 1724 */       break;
/*      */     case 4:
/* 1727 */       s.linkType = value;
/* 1728 */       break;
/*      */     case 5:
/* 1731 */       s.linkTrackVars = value;
/* 1732 */       break;
/*      */     case 6:
/* 1735 */       s.linkTrackEvents = value;
/* 1736 */       break;
/*      */     case 7:
/* 1739 */       s.dc = value;
/* 1740 */       break;
/*      */     case 8:
/* 1743 */       s.trackingServer = value;
/* 1744 */       break;
/*      */     case 9:
/* 1747 */       s.trackingServerSecure = value;
/* 1748 */       break;
/*      */     case 10:
/* 1751 */       s.userAgent = value;
/* 1752 */       break;
/*      */     case 11:
/* 1755 */       s.dynamicVariablePrefix = value;
/* 1756 */       break;
/*      */     case 12:
/* 1759 */       s.visitorID = value;
/* 1760 */       break;
/*      */     case 13:
/* 1763 */       s.charSet = value;
/* 1764 */       break;
/*      */     case 14:
/* 1767 */       s.visitorNamespace = value;
/* 1768 */       break;
/*      */     case 15:
/* 1771 */       s.pageName = value;
/* 1772 */       break;
/*      */     case 16:
/* 1775 */       s.pageURL = value;
/* 1776 */       break;
/*      */     case 17:
/* 1779 */       s.referrer = value;
/* 1780 */       break;
/*      */     case 18:
/* 1783 */       s.currencyCode = value;
/* 1784 */       break;
/*      */     case 19:
/* 1787 */       s.purchaseID = value;
/* 1788 */       break;
/*      */     case 20:
/* 1791 */       s.channel = value;
/* 1792 */       break;
/*      */     case 21:
/* 1795 */       s.server = value;
/* 1796 */       break;
/*      */     case 22:
/* 1799 */       s.pageType = value;
/* 1800 */       break;
/*      */     case 23:
/* 1803 */       s.transactionID = value;
/* 1804 */       break;
/*      */     case 24:
/* 1807 */       s.campaign = value;
/* 1808 */       break;
/*      */     case 25:
/* 1811 */       s.state = value;
/* 1812 */       break;
/*      */     case 26:
/* 1815 */       s.zip = value;
/* 1816 */       break;
/*      */     case 27:
/* 1819 */       s.events = value;
/* 1820 */       break;
/*      */     case 28:
/* 1823 */       s.products = value;
/* 1824 */       break;
/*      */     case 29:
/* 1827 */       s.hier1 = value;
/* 1828 */       break;
/*      */     case 30:
/* 1831 */       s.hier2 = value;
/* 1832 */       break;
/*      */     case 31:
/* 1835 */       s.hier3 = value;
/* 1836 */       break;
/*      */     case 32:
/* 1839 */       s.hier4 = value;
/* 1840 */       break;
/*      */     case 33:
/* 1843 */       s.hier5 = value;
/* 1844 */       break;
/*      */     case 34:
/* 1847 */       s.prop1 = value;
/* 1848 */       break;
/*      */     case 35:
/* 1851 */       s.prop2 = value;
/* 1852 */       break;
/*      */     case 36:
/* 1855 */       s.prop3 = value;
/* 1856 */       break;
/*      */     case 37:
/* 1859 */       s.prop4 = value;
/* 1860 */       break;
/*      */     case 38:
/* 1863 */       s.prop5 = value;
/* 1864 */       break;
/*      */     case 39:
/* 1867 */       s.prop6 = value;
/* 1868 */       break;
/*      */     case 40:
/* 1871 */       s.prop7 = value;
/* 1872 */       break;
/*      */     case 41:
/* 1875 */       s.prop8 = value;
/* 1876 */       break;
/*      */     case 42:
/* 1879 */       s.prop9 = value;
/* 1880 */       break;
/*      */     case 43:
/* 1883 */       s.prop10 = value;
/* 1884 */       break;
/*      */     case 44:
/* 1887 */       s.prop11 = value;
/* 1888 */       break;
/*      */     case 45:
/* 1891 */       s.prop12 = value;
/* 1892 */       break;
/*      */     case 46:
/* 1895 */       s.prop13 = value;
/* 1896 */       break;
/*      */     case 47:
/* 1899 */       s.prop14 = value;
/* 1900 */       break;
/*      */     case 48:
/* 1903 */       s.prop15 = value;
/* 1904 */       break;
/*      */     case 49:
/* 1907 */       s.prop16 = value;
/* 1908 */       break;
/*      */     case 50:
/* 1911 */       s.prop17 = value;
/* 1912 */       break;
/*      */     case 51:
/* 1915 */       s.prop18 = value;
/* 1916 */       break;
/*      */     case 52:
/* 1919 */       s.prop19 = value;
/* 1920 */       break;
/*      */     case 53:
/* 1923 */       s.prop20 = value;
/* 1924 */       break;
/*      */     case 54:
/* 1927 */       s.prop21 = value;
/* 1928 */       break;
/*      */     case 55:
/* 1931 */       s.prop22 = value;
/* 1932 */       break;
/*      */     case 56:
/* 1935 */       s.prop23 = value;
/* 1936 */       break;
/*      */     case 57:
/* 1939 */       s.prop24 = value;
/* 1940 */       break;
/*      */     case 58:
/* 1943 */       s.prop25 = value;
/* 1944 */       break;
/*      */     case 59:
/* 1947 */       s.prop26 = value;
/* 1948 */       break;
/*      */     case 60:
/* 1951 */       s.prop27 = value;
/* 1952 */       break;
/*      */     case 61:
/* 1955 */       s.prop28 = value;
/* 1956 */       break;
/*      */     case 62:
/* 1959 */       s.prop29 = value;
/* 1960 */       break;
/*      */     case 63:
/* 1963 */       s.prop30 = value;
/* 1964 */       break;
/*      */     case 64:
/* 1967 */       s.prop31 = value;
/* 1968 */       break;
/*      */     case 65:
/* 1971 */       s.prop32 = value;
/* 1972 */       break;
/*      */     case 66:
/* 1975 */       s.prop33 = value;
/* 1976 */       break;
/*      */     case 67:
/* 1979 */       s.prop34 = value;
/* 1980 */       break;
/*      */     case 68:
/* 1983 */       s.prop35 = value;
/* 1984 */       break;
/*      */     case 69:
/* 1987 */       s.prop36 = value;
/* 1988 */       break;
/*      */     case 70:
/* 1991 */       s.prop37 = value;
/* 1992 */       break;
/*      */     case 71:
/* 1995 */       s.prop38 = value;
/* 1996 */       break;
/*      */     case 72:
/* 1999 */       s.prop39 = value;
/* 2000 */       break;
/*      */     case 73:
/* 2003 */       s.prop40 = value;
/* 2004 */       break;
/*      */     case 74:
/* 2007 */       s.prop41 = value;
/* 2008 */       break;
/*      */     case 75:
/* 2011 */       s.prop42 = value;
/* 2012 */       break;
/*      */     case 76:
/* 2015 */       s.prop43 = value;
/* 2016 */       break;
/*      */     case 77:
/* 2019 */       s.prop44 = value;
/* 2020 */       break;
/*      */     case 78:
/* 2023 */       s.prop45 = value;
/* 2024 */       break;
/*      */     case 79:
/* 2027 */       s.prop46 = value;
/* 2028 */       break;
/*      */     case 80:
/* 2031 */       s.prop47 = value;
/* 2032 */       break;
/*      */     case 81:
/* 2035 */       s.prop48 = value;
/* 2036 */       break;
/*      */     case 82:
/* 2039 */       s.prop49 = value;
/* 2040 */       break;
/*      */     case 83:
/* 2043 */       s.prop50 = value;
/* 2044 */       break;
/*      */     case 84:
/* 2047 */       s.eVar1 = value;
/* 2048 */       break;
/*      */     case 85:
/* 2051 */       s.eVar2 = value;
/* 2052 */       break;
/*      */     case 86:
/* 2055 */       s.eVar3 = value;
/* 2056 */       break;
/*      */     case 87:
/* 2059 */       s.eVar4 = value;
/* 2060 */       break;
/*      */     case 88:
/* 2063 */       s.eVar5 = value;
/* 2064 */       break;
/*      */     case 89:
/* 2067 */       s.eVar6 = value;
/* 2068 */       break;
/*      */     case 90:
/* 2071 */       s.eVar7 = value;
/* 2072 */       break;
/*      */     case 91:
/* 2075 */       s.eVar8 = value;
/* 2076 */       break;
/*      */     case 92:
/* 2079 */       s.eVar9 = value;
/* 2080 */       break;
/*      */     case 93:
/* 2083 */       s.eVar10 = value;
/* 2084 */       break;
/*      */     case 94:
/* 2087 */       s.eVar11 = value;
/* 2088 */       break;
/*      */     case 95:
/* 2091 */       s.eVar12 = value;
/* 2092 */       break;
/*      */     case 96:
/* 2095 */       s.eVar13 = value;
/* 2096 */       break;
/*      */     case 97:
/* 2099 */       s.eVar14 = value;
/* 2100 */       break;
/*      */     case 98:
/* 2103 */       s.eVar15 = value;
/* 2104 */       break;
/*      */     case 99:
/* 2107 */       s.eVar16 = value;
/* 2108 */       break;
/*      */     case 100:
/* 2111 */       s.eVar17 = value;
/* 2112 */       break;
/*      */     case 101:
/* 2115 */       s.eVar18 = value;
/* 2116 */       break;
/*      */     case 102:
/* 2119 */       s.eVar19 = value;
/* 2120 */       break;
/*      */     case 103:
/* 2123 */       s.eVar20 = value;
/* 2124 */       break;
/*      */     case 104:
/* 2127 */       s.eVar21 = value;
/* 2128 */       break;
/*      */     case 105:
/* 2131 */       s.eVar22 = value;
/* 2132 */       break;
/*      */     case 106:
/* 2135 */       s.eVar23 = value;
/* 2136 */       break;
/*      */     case 107:
/* 2139 */       s.eVar24 = value;
/* 2140 */       break;
/*      */     case 108:
/* 2143 */       s.eVar25 = value;
/* 2144 */       break;
/*      */     case 109:
/* 2147 */       s.eVar26 = value;
/* 2148 */       break;
/*      */     case 110:
/* 2151 */       s.eVar27 = value;
/* 2152 */       break;
/*      */     case 111:
/* 2155 */       s.eVar28 = value;
/* 2156 */       break;
/*      */     case 112:
/* 2159 */       s.eVar29 = value;
/* 2160 */       break;
/*      */     case 113:
/* 2163 */       s.eVar30 = value;
/* 2164 */       break;
/*      */     case 114:
/* 2167 */       s.eVar31 = value;
/* 2168 */       break;
/*      */     case 115:
/* 2171 */       s.eVar32 = value;
/* 2172 */       break;
/*      */     case 116:
/* 2175 */       s.eVar33 = value;
/* 2176 */       break;
/*      */     case 117:
/* 2179 */       s.eVar34 = value;
/* 2180 */       break;
/*      */     case 118:
/* 2183 */       s.eVar35 = value;
/* 2184 */       break;
/*      */     case 119:
/* 2187 */       s.eVar36 = value;
/* 2188 */       break;
/*      */     case 120:
/* 2191 */       s.eVar37 = value;
/* 2192 */       break;
/*      */     case 121:
/* 2195 */       s.eVar38 = value;
/* 2196 */       break;
/*      */     case 122:
/* 2199 */       s.eVar39 = value;
/* 2200 */       break;
/*      */     case 123:
/* 2203 */       s.eVar40 = value;
/* 2204 */       break;
/*      */     case 124:
/* 2207 */       s.eVar41 = value;
/* 2208 */       break;
/*      */     case 125:
/* 2211 */       s.eVar42 = value;
/* 2212 */       break;
/*      */     case 126:
/* 2215 */       s.eVar43 = value;
/* 2216 */       break;
/*      */     case 127:
/* 2219 */       s.eVar44 = value;
/* 2220 */       break;
/*      */     case 128:
/* 2223 */       s.eVar45 = value;
/* 2224 */       break;
/*      */     case 129:
/* 2227 */       s.eVar46 = value;
/* 2228 */       break;
/*      */     case 130:
/* 2231 */       s.eVar47 = value;
/* 2232 */       break;
/*      */     case 131:
/* 2235 */       s.eVar48 = value;
/* 2236 */       break;
/*      */     case 132:
/* 2239 */       s.eVar49 = value;
/* 2240 */       break;
/*      */     case 133:
/* 2243 */       s.eVar50 = value;
/* 2244 */       break;
/*      */     case 134:
/* 2247 */       s.pe = value;
/* 2248 */       break;
/*      */     case 135:
/* 2251 */       s.pev1 = value;
/* 2252 */       break;
/*      */     case 136:
/* 2255 */       s.pev2 = value;
/*      */     }
/*      */   }
/*      */ }

/* Location:           /Users/Oleksandr_Dodatko/Projects/ThomsonReuters/ReutersInsider/iPhone/branches/RI-2011.09.31-1.9/trunk/lib/iOmnitureTracker/doc/OmnitureAppMeasurement-BlackBerry.jar
 * Qualified Name:     com.omniture.blackberry.AppMeasurement
 * JD-Core Version:    0.6.0
 */