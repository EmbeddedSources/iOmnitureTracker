package com.omniture.blackberry;

public abstract interface AppMeasurementDelegate
{
  public abstract void doPlugins(AppMeasurement paramAppMeasurement);
}

/* Location:           /Users/Oleksandr_Dodatko/Projects/ThomsonReuters/ReutersInsider/iPhone/branches/RI-2011.09.31-1.9/trunk/lib/iOmnitureTracker/doc/OmnitureAppMeasurement-BlackBerry.jar
 * Qualified Name:     com.omniture.blackberry.AppMeasurementDelegate
 * JD-Core Version:    0.6.0
 */