/*    */ package com.omniture.blackberry;
/*    */ 
/*    */ import javax.microedition.io.Connector;
/*    */ import javax.microedition.io.HttpConnection;
/*    */ 
/*    */ class Request
/*    */ {
/*    */   private String requestString;
/*    */   private String userAgent;
/*    */   private String localeID;
/*    */ 
/*    */   public Request(String requestString, String userAgent, String localeID)
/*    */   {
/* 19 */     this.requestString = requestString;
/* 20 */     this.userAgent = userAgent;
/* 21 */     this.localeID = localeID;
/*    */   }
/*    */ 
/*    */   public void send()
/*    */   {
/*    */     try {
/* 27 */       HttpConnection connection = (HttpConnection)Connector.open(this.requestString);
/*    */ 
/* 30 */       connection.setRequestProperty("User-Agent", this.userAgent);
/* 31 */       connection.setRequestProperty("Accept-Language", this.localeID);
/*    */ 
/* 34 */       connection.getResponseCode();
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Oleksandr_Dodatko/Projects/ThomsonReuters/ReutersInsider/iPhone/branches/RI-2011.09.31-1.9/trunk/lib/iOmnitureTracker/doc/OmnitureAppMeasurement-BlackBerry.jar
 * Qualified Name:     com.omniture.blackberry.Request
 * JD-Core Version:    0.6.0
 */